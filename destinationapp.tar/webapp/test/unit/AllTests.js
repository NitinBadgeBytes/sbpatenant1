sap.ui.define([
	"destinationapp/test/unit/controller/destinationView.controller"
], function () {
	"use strict";
});
